package legionario;

import java.io.*;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

public class Legionario implements Serializable {
    private enum Roles{
        explorador,
        logistica,
        soldado
    }
    private int id;
    private String rol;
    private boolean ocupado;
    private boolean tareaTerminada;

    public boolean isOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Legionario(){}
    public Legionario(String host, int port){
        this.tareaTerminada = false;
        this.ocupado = false;
        try {
            setRandomRol();
            Socket server = new Socket(host, port);
            InputStream inputStream = server.getInputStream();
            DataInputStream reader = new DataInputStream(inputStream);
            OutputStream outputStream = server.getOutputStream();
            DataOutputStream writer = new DataOutputStream(outputStream);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            System.out.println(reader.readUTF());
            this.setId(reader.readInt());
            objectOutputStream.writeObject(this);

            while (true){
                System.out.println("hola");
                int idAux = reader.readInt();
                if (idAux == this.getId()){
                    System.out.println("hago orden");
                    String[] orden = reader.readUTF().split("\\.");
                    switch (orden[1]){
                        case "traer_cosa":
                            try {
                                writer.writeUTF("idLegionario."+getId()+".busy."+"true");
                                System.out.println("qweqwrqwr");
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                writer.writeUTF("idLegionario."+getId()+".busy."+"false");
                            }
                            break;
                        case "mandar_mensaje":
                            try {
                                writer.writeUTF("idLegionario."+getId()+".busy."+"true");
                                System.out.println("qweqwrqwr");
                                Thread.sleep(3000);
                            } catch (InterruptedException e) {
                                writer.writeUTF("idLegionario."+getId()+".busy."+"true");
                            }
                            break;
                        case "vigilar":
                            try {
                                writer.writeUTF("idLegionario."+getId()+".busy."+"true");
                                System.out.println("qweqwrqwr");
                                Thread.sleep(5000);
                            } catch (InterruptedException e) {
                                writer.writeUTF("idLegionario."+getId()+".busy."+"false");
                            }
                            break;
                    }
                    System.out.println("he terminado las tareas");
                    writer.writeUTF("idLegionario."+getId()+".busy."+"false");
                }else{
                    System.out.println("no hago nada");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void setRandomRol(){
        Random random = new Random();
        Roles[] roles = Roles.values();
        this.rol = String.valueOf(roles[random.nextInt(roles.length)]);
        System.out.println(this.rol);
    }

}

