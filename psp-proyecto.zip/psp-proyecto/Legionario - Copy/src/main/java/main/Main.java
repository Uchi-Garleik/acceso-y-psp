package main;

import legionario.Legionario;

public class Main {
    public static void main(String[] args) {
        Legionario legionario = new Legionario("localhost", 4001);
    }
}
