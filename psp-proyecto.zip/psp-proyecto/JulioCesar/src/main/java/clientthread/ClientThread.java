package clientthread;

import centurion.Centurion;
import encriptacion.Enigma;
import juliocesar.JulioCesar;
import orden.Cosa;
import orden.Orden;
import orden.OrdenTraerCosa;
import orden.TipoOrden;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class ClientThread extends Thread implements Serializable {
    private Socket socketCliente;
    boolean tr = true;
    private JulioCesar julioCesar;
    boolean creandoOrden;

    public ClientThread(Socket socketCliente, JulioCesar julioCesar) {
        this.socketCliente = socketCliente;
        this.julioCesar = julioCesar;
    }

    Scanner scanner = new Scanner(System.in);

    @Override
    public void run() {
        try (
                OutputStream outputStream = socketCliente.getOutputStream();
                InputStream inputStream = socketCliente.getInputStream();
                DataOutputStream dataOutputStream = new DataOutputStream(outputStream);
                DataInputStream dataInputStream = new DataInputStream(inputStream);

//                ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
//                ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
        ) {
            Random random = new Random();
            dataOutputStream.writeUTF("\"[" + socketCliente.getInetAddress() + "] Conexión establecida exitosamente."); // 1º Write
            int idCenturion = dataInputStream.readInt(); // 1º Read
            julioCesar.addCenturion(idCenturion, "centurion");
//            String[] info = dataInputStream.readUTF().split("\\.");
//            if (info[3].equals("false")){
//                System.out.println("e");
//            }
//            Centurion centurionaux = (Centurion) objectInputStream.readObject(); // 2º Read
//            System.out.println(centurionaux.getId());
            while (tr) {
//                if (creandoOrden){
//                    dataOutputStream.writeUTF("ocupado");
//                }else{
                int accionID = dataInputStream.readInt();
                if (accionID == 1) {
                    String tipoOrden;
                    tipoOrden = String.valueOf(TipoOrden.values()[random.nextInt(TipoOrden.values().length)]);
                    dataOutputStream.writeUTF(tipoOrden);
                    String[] condicional = dataInputStream.readUTF().split("\\.");
                    if (!condicional[1].equals("null")) {
                        switch (tipoOrden) {
                            case "TRAER_COSA":
                                Cosa cosa = Cosa.values()[random.nextInt(Cosa.values().length)];
                                if (String.valueOf(cosa).equals("PAPEL_PERGAMINO")) {
                                    dataOutputStream.writeUTF("cosa." + String.valueOf(cosa));
                                } else {
                                    System.out.println("¿Cuantas + " + cosa + " quieres mandar?");
                                    int cantidad = random.nextInt(10) + 1;
                                    dataOutputStream.writeUTF(("tipoOrden." + tipoOrden + ".cosa." + String.valueOf(cosa) + ".cantidad." + cantidad).toLowerCase());
                                }
                                break;
                            case "MANDAR_MENSAJE":
                                String mensaje = "mensa";
                                String receptor = "recep";
                                String idReceptor = "1";
                                dataOutputStream.writeUTF(("tipoOrden." + tipoOrden + ".receptor." + receptor + ".id." + idReceptor + ".mensaje." + mensaje).toLowerCase());
                                break;
                            case "VIGILAR":
                                int tiempoVigilar = random.nextInt(30) + 1;
                                String objetoVigilar = "objetoVigia";
                                dataOutputStream.writeUTF(("tipoOrden." + tipoOrden + ".objeto." + objetoVigilar + ".tiempo." + tiempoVigilar).toLowerCase());
                                break;
                        }
                    }
                } else {
                    System.out.println("ok");
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                socketCliente.close();
                System.out.println("[" + socketCliente.getLocalSocketAddress() + "] Conexión cerrada exitosamente.");
            } catch (IOException e) {
                System.out.println("[" + socketCliente.getLocalSocketAddress() + "] Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }
}

