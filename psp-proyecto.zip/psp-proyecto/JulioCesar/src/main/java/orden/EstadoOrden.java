package orden;

public enum EstadoOrden {

    PENDIENTE,
    EN_PROGRESO,
    FINALIZADA

}
