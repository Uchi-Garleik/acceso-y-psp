package orden;

public enum Cosa {

    CERVEZA,
    PRISIONEROS,
    PAPEL_PERGAMINO

}
