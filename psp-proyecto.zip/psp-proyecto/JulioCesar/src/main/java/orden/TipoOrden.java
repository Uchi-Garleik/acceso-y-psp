package orden;

public enum TipoOrden {

    TRAER_COSA,
    MANDAR_MENSAJE,
    VIGILAR

}
