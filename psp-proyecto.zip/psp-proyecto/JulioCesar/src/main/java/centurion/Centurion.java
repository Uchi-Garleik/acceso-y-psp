package centurion;

public class Centurion {
    private String[] info;
    private static int centurionCounter;
    private int id;
    public int getId(){
        return 1;
    }
}
