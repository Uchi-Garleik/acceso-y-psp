package threadlegionario;

import centurionserver.CenturionServer;
import legionario.Legionario;

import javax.xml.crypto.Data;
import java.io.*;
import java.net.Socket;
import java.util.ArrayList;

public class ThreadLegionario extends Thread{
    private Socket socketCliente;
    boolean tr = true;
    private CenturionServer centurionServer;
    DataInputStream dataInputStream;
    DataOutputStream dataOutputStream;
    private static int contadorLegionarios;
    private int idLegionario;

    public ThreadLegionario(Socket socketCliente, CenturionServer centurionServer){
        this.socketCliente = socketCliente;
        this.centurionServer = centurionServer;
    }


    @Override
    public void run() {
        try {
            OutputStream outputStream = socketCliente.getOutputStream();
            InputStream inputStream = socketCliente.getInputStream();
            dataOutputStream = new DataOutputStream(outputStream);
            dataInputStream = new DataInputStream(inputStream);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);
            dataOutputStream.writeUTF("\"[" + socketCliente.getInetAddress() + "] Conexión establecida exitosamente.");
            contadorLegionarios++;
            idLegionario = contadorLegionarios;
            dataOutputStream.writeInt(idLegionario);
            Legionario legionario = (Legionario) objectInputStream.readObject();
            centurionServer.addLegionario(legionario.getId(), legionario);
//            System.out.println("id."+legionario.getId() +".rol." +legionario.getRol());

            while (tr){
                System.out.println("hola?");
                String[] info = dataInputStream.readUTF().split("\\.");
                String x = "";
                for (int i = 0; i < info.length; i++) {
                    x += info[i];
                }
                System.out.println(x);
                ArrayList<Legionario> legionarios = centurionServer.findAllLegionarios();
                for (Legionario legionarioAux : legionarios) {
                    if (legionarioAux.getId() == Integer.parseInt(info[1])){
                        if (info[3].equals("true")){
                            legionarioAux.setOcupado(true);
                        }else{
                            legionarioAux.setOcupado(false);
                        }
                    }
                }
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            try {
                socketCliente.close();
                System.out.println("[" + socketCliente.getLocalSocketAddress() + "] Conexión cerrada exitosamente.");
            } catch (IOException e) {
                System.out.println("[" + socketCliente.getLocalSocketAddress() + "] Error al cerrar la conexión: " + e.getMessage());
            }
        }
    }

    public void mandarOrden(String orden) {
        int idAux = Integer.parseInt(orden.split("idLegionario")[1].replaceAll("\\.",""));
//        ArrayList<Legionario> legionarios = this.centurionServer.findAllLegionarios();
//        for (Legionario legionario : legionarios) {
            try {
                Legionario legionario = this.centurionServer.getCenturion(idAux);
//                System.out.println(legionario.isOcupado());
                if (!legionario.isOcupado()){
                    System.out.println("este legionario ESTA LIBRE");
                    dataOutputStream.writeInt(idAux);
                    dataOutputStream.writeUTF(orden);
                }else{
                    System.out.println("este legionario esta ocupado");
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
//        }
    }
}
