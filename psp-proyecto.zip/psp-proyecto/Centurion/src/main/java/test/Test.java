package test;

public class Test {
    public static void main(String[] args) {
        String s = "receptor.recep.id.1.mensaje.mensa.idLegionario.1";
        String sAux = s.split("idLegionario")[1].replaceAll("\\.","");
//        System.out.println(sAux);
    }
}
