package centurion;

import centurionserver.CenturionServer;
import legionario.Legionario;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class Centurion implements Serializable {
    private String[] info;
    private static int centurionCounter;
    private int id;
    boolean tareaAsignada;
    boolean tareaTerminada;
    boolean tr = true;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Centurion(String host, int port) {
        this.tareaAsignada = false;
        this.tareaTerminada = false;
        centurionCounter++;
        id = centurionCounter;
        try {
            Socket server = new Socket(host, port);
            InputStream inputStream = server.getInputStream();
            DataInputStream reader = new DataInputStream(inputStream);
            OutputStream outputStream = server.getOutputStream();
            DataOutputStream writer = new DataOutputStream(outputStream);

//            ObjectOutputStream objectOutputStream = new ObjectOutputStream(outputStream);
//            ObjectInputStream objectInputStream = new ObjectInputStream(inputStream);

            System.out.println(reader.readUTF()); // 1º Read
            writer.writeInt(getId()); // 1º Write

//            objectOutputStream.writeObject(this); // 2º Write


            CenturionServer centurionServer = new CenturionServer(4001);
            Thread serverThread = new Thread(centurionServer);
            serverThread.start();
            while (tr) {
                writer.writeInt(id);
                String tipoOrden = reader.readUTF();
                Legionario legionarioFound = checkOrder(centurionServer, tipoOrden);
                if (legionarioFound == null) {
                    writer.writeUTF("legionario." + "null");
                } else {
                    writer.writeUTF("legionario." + "notnull");
                }
                if (legionarioFound != null) {
                    String orden = "";
                    String ordenAux = "";
                    switch (tipoOrden) {
                        case "TRAER_COSA":
                            orden = reader.readUTF();
                            ordenAux = String.valueOf(orden) + ".idLegionario." + legionarioFound.getId();
                            centurionServer.mandarOrden(ordenAux);
                            break;
                        case "MANDAR_MENSAJE":
                            orden = reader.readUTF();
                            ordenAux = String.valueOf(orden) + ".idLegionario." + legionarioFound.getId();
                            centurionServer.mandarOrden(ordenAux);
                            break;
                        case "VIGILAR":
                            orden = reader.readUTF();
                            ordenAux = String.valueOf(orden) + ".idLegionario." + legionarioFound.getId();
                            centurionServer.mandarOrden(ordenAux);
                            break;
                    }
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
//            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private Legionario checkOrder(CenturionServer centurionServer, String tipoOrden) {
        ArrayList<Legionario> legionarios = centurionServer.findAllLegionarios();
        for (Legionario legionario : legionarios) {
            switch (legionario.getRol()) {
                case "explorador":
                    if (tipoOrden.equals("MANDAR_MENSAJE")) {
//                        System.out.println("Legionario " + legionario.getRol() + " is compatible with the order.");
                        // Perform additional actions or return true if a compatible legionario is found
                        return legionario;
                    }
                    break;
                case "logistica":
                    if (tipoOrden.equals("TRAER_COSA")) {
//                        System.out.println("Legionario " + legionario.getRol() + " is compatible with the order.");
                        // Perform additional actions or return true if a compatible legionario is found
                        return legionario;
                    }
                    break;
                case "soldado":
                    if (tipoOrden.equals("VIGILAR")) {
//                        System.out.println("Legionario " + legionario.getRol() + " is compatible with the order.");
                        // Perform additional actions or return true if a compatible legionario is found
                        return legionario;
                    }
                    break;
            }
        }

        // If no compatible legionario is found
//        System.out.println("No compatible legionario found for the order.");
        return null;
    }

}
