package centurionserver;

import legionario.Legionario;
import threadlegionario.ThreadLegionario;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CenturionServer implements Runnable{
    private Map<Integer, Legionario> legionarioMap;
    private final int PORT;
    ThreadLegionario threadLegionario;
    public CenturionServer(int port){
        this.PORT = port;
        this.legionarioMap = new HashMap<>();
    }

    public void addLegionario(int legionarioID, Legionario legionario){
        legionarioMap.put(legionarioID,legionario);
    }
    public Legionario getCenturion(int legionarioID) {
        return legionarioMap.get(legionarioID);
    }
    public ArrayList<Legionario> findAllLegionarios() {
        return new ArrayList<>(legionarioMap.values());
    }

    @Override
    public void run() {
        try (ServerSocket server = new ServerSocket(PORT)) {
            System.out.println("Servidor escuchando en el puerto " + PORT);
            while (true) {
                Socket client = server.accept(); // Bloqueante
                System.out.println("[" + server.getLocalSocketAddress() + "] Cliente aceptado.");
                threadLegionario = new ThreadLegionario(client, this);
                threadLegionario.start();
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    public void mandarOrden(String orden) {
//        int idAux = Integer.parseInt(orden.split("idLegionario")[1].replaceAll("\\.",""));
//        ArrayList<Legionario> legionarios = findAllLegionarios();
//        for (Legionario legionario : legionarios) {
//            if (legionario.getId() == idAux){
//                threadLegionario.mandarOrden(orden);
//            }
//        }
        threadLegionario.mandarOrden(orden);
    }
}
