package main;

import centurion.Centurion;

public class Main {
    public static void main(String[] args) {
        Centurion centurion = new Centurion("localhost", 4000);
    }
}
